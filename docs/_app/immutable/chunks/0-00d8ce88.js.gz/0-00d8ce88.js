import{default as t}from"../components/pages/_layout.svelte-0887b199.js";export{t as component};
