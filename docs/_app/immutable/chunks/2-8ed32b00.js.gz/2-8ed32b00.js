import{default as t}from"../components/pages/_page.svelte-ebc46862.js";export{t as component};
