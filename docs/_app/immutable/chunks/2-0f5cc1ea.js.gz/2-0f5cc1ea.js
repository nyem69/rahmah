import{default as t}from"../components/pages/_page.svelte-21348d68.js";export{t as component};
