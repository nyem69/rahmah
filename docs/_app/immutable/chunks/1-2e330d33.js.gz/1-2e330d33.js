import{default as t}from"../components/error.svelte-ea2554ce.js";export{t as component};
